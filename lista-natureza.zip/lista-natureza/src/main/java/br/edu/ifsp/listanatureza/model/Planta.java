package br.edu.ifsp.listanatureza.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Planta {
    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    private Long id;
    private String nomePlanta;
    private String especiePlanta;
    private String corPlanta;

    @ManyToMany(mappedBy = "plantas", cascade = CascadeType.ALL)
    private List<Animal> animais;

    public Planta() {
        
    }

    public Planta(String nomePlanta, String especiePlanta, String corPlanta) {
        this.nomePlanta = nomePlanta;
        this.especiePlanta = especiePlanta;
        this.corPlanta = corPlanta;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNomePlanta() {
        return nomePlanta;
    }

    public void setNomePlanta(String nomePlanta) {
        this.nomePlanta = nomePlanta;
    }

    public String getEspeciePlanta() {
        return especiePlanta;
    }

    public void setEspeciePlanta(String especiePlanta) {
        this.especiePlanta = especiePlanta;
    }

    public String getCorPlanta() {
        return corPlanta;
    }

    public void setCorPlanta(String corPlanta) {
        this.corPlanta = corPlanta;
    }    

    
    
}
