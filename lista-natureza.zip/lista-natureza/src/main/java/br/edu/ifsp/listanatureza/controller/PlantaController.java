package br.edu.ifsp.listanatureza.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


import br.edu.ifsp.listanatureza.model.PlantaRepository;
import br.edu.ifsp.listanatureza.model.Planta;

@RestController
public class PlantaController {
 
    @Autowired
    PlantaRepository plantaRepository;

    @GetMapping("/listasFlora")
    public List<Planta> getListasFlora(){
        return (List<Planta>) plantaRepository.findAll();
    }
    @PostMapping("/listasFlora/criar")
    public Planta postLista(@RequestBody Planta planta){
        return plantaRepository.save(planta);
    }
    @PutMapping("/listasFlora/alterar_flora/{id}")
      public Planta putPlanta(@PathVariable Long id, @RequestBody Planta planta){
          if(plantaRepository.findById(id).isPresent()){
              Planta plantaBanco = plantaRepository.findById(id).get();
              plantaBanco.setNomePlanta(planta.getNomePlanta());
              plantaBanco.setEspeciePlanta(planta.getEspeciePlanta());
              plantaBanco.setCorPlanta(planta.getCorPlanta());
              plantaRepository.save(plantaBanco);         
              return planta;
          }
          return null;
      }
    @GetMapping("/listasFlora/{id}")
      @ResponseBody
      public Planta getPlantaById(@PathVariable("id") Planta planta){
          return planta;
    }
    @DeleteMapping("/listasFlora/deletar_flora/{id}")
      public Planta deleteFlora(@PathVariable Long id){
          if(plantaRepository.findById(id).isPresent()){
              Planta planta = plantaRepository.findById(id).get();
              plantaRepository.delete(planta);
              return planta;
          }
          return null;
        }
    }

