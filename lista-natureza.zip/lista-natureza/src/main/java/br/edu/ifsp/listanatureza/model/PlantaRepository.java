package br.edu.ifsp.listanatureza.model;

import org.springframework.data.repository.CrudRepository;

public interface PlantaRepository extends CrudRepository <Planta, Long>{
    
}
